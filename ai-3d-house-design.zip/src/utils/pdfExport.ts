import { jsPDF } from "jspdf";
import { HouseDesign, MaterialItem } from "../types";

export const exportDesignPDF = (design: HouseDesign) => {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const primaryPurple = "#7C3AED";
  const darkGray = "#1F2937";
  const successGreen = "#10B981";

  // Page 1: Design Specification Cover & Cost Summary
  // --- Header ---
  doc.setFillColor(124, 58, 237); // Purple header accent
  doc.rect(0, 0, 210, 38, "F");

  doc.setTextColor(255, 255, 255);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(22);
  doc.text("SMART AI HOUSE SCHEMATIC", 15, 18);

  doc.setFont("Helvetica", "normal");
  doc.setFontSize(10);
  doc.text("Premium AI Architecture Assistant - Pakistan standard 2026", 15, 25);
  doc.text(`Generated On: ${new Date(design.createdAt).toLocaleDateString()}`, 15, 30);

  // --- Document Title Card ---
  doc.setTextColor(31, 41, 55);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(16);
  doc.text(`${design.title} Layout Report`, 15, 52);

  // Specifications
  doc.setDrawColor(229, 231, 235);
  doc.setFillColor(249, 250, 251);
  doc.rect(15, 58, 180, 42, "FD");

  doc.setTextColor(107, 114, 128);
  doc.setFontSize(9);
  doc.setFont("Helvetica", "bold");
  doc.text("PLOT DIMENSION", 20, 66);
  doc.text("FLOORS COUNT", 80, 66);
  doc.text("ARCHITECTURAL STYLE", 140, 66);

  doc.setTextColor(17, 24, 39);
  doc.setFontSize(11);
  doc.setFont("Helvetica", "normal");
  doc.text(`${design.plotSize.value} Marla (${design.plotSize.widthFt}' x ${design.plotSize.lengthFt}')`, 20, 72);
  doc.text(`${design.floorsCount} Storey`, 80, 72);
  doc.text(`${design.style}`, 140, 72);

  doc.setTextColor(107, 114, 128);
  doc.setFontSize(9);
  doc.setFont("Helvetica", "bold");
  doc.text("TARGET BUDGET", 20, 84);
  doc.text("ESTIMATED TOTAL", 80, 84);
  doc.text("VARIATION DELTA", 140, 84);

  const budgetFormatted = `PKR ${design.budgetPKR.toLocaleString()}`;
  const totalCostFormatted = `PKR ${design.costBreakdown.totalCost.toLocaleString()}`;
  const delta = design.costBreakdown.totalCost - design.budgetPKR;
  const deltaFormatted = delta <= 0 
    ? `PKR ${(Math.abs(delta)).toLocaleString()} Under Budget` 
    : `PKR ${delta.toLocaleString()} Over Target`;

  doc.setTextColor(16, 185, 129); // success indicator green
  doc.text(budgetFormatted, 20, 90);
  doc.setTextColor(124, 58, 237); // purple
  doc.text(totalCostFormatted, 80, 90);
  doc.setTextColor(delta <= 0 ? 16 : 220, delta <= 0 ? 185 : 38, delta <= 0 ? 129 : 38);
  doc.text(deltaFormatted, 140, 90);

  // --- Cost Breakdown Details ---
  doc.setTextColor(31, 41, 55);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(12);
  doc.text("Construction Category Estimates", 15, 112);

  let categoryY = 120;
  design.costBreakdown.categories.forEach((cat) => {
    doc.setDrawColor(243, 244, 246);
    doc.setFillColor(255, 255, 255);
    doc.rect(15, categoryY, 180, 16, "FD");

    // Indicator bubble
    doc.setFillColor(124, 58, 237);
    doc.rect(18, categoryY + 4, 3, 8, "F");

    doc.setTextColor(17, 24, 39);
    doc.setFontSize(10);
    doc.setFont("Helvetica", "bold");
    doc.text(cat.name, 25, categoryY + 10);

    doc.setFont("Helvetica", "normal");
    doc.text(`PKR ${cat.amount.toLocaleString()}`, 120, categoryY + 10);
    doc.text(`${cat.percentage}%`, 175, categoryY + 10);

    categoryY += 21;
  });

  // --- AI Architectural Feedback ---
  doc.setTextColor(31, 41, 55);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(12);
  doc.text("AI Professional Architecture Audit", 15, 192);

  doc.setFillColor(243, 244, 246);
  doc.rect(15, 198, 180, 36, "F");

  doc.setTextColor(55, 65, 81);
  doc.setFont("Helvetica", "normal");
  doc.setFontSize(9.5);
  const splitText = doc.splitTextToSize(design.aiFeedback.description, 170);
  doc.text(splitText, 20, 206);

  // Ratings
  doc.setFillColor(124, 58, 237);
  doc.rect(20, 240, 30, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(8);
  doc.setFont("Helvetica", "bold");
  doc.text(`Space Eff: ${design.aiFeedback.spaceEfficiencyRating}/10`, 22, 245);

  doc.setFillColor(16, 185, 129);
  doc.rect(55, 240, 30, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.text(`Air Vent: ${design.aiFeedback.ventilationRating}/10`, 57, 245);

  // --- Footer on Page 1 ---
  doc.setDrawColor(229, 231, 235);
  doc.line(15, 275, 195, 275);

  doc.setTextColor(156, 163, 175);
  doc.setFontSize(8.5);
  doc.setFont("Helvetica", "bold");
  doc.text("DESIGNED BY MR MUHAMMAD USMAN AWAN", 15, 282);
  doc.setFont("Helvetica", "normal");
  doc.text("Page 1 of 2", 185, 282);


  // Page 2: Material Lists & Room Schematic Specs
  doc.addPage();

  doc.setFillColor(124, 58, 237); // Purple header band page 2
  doc.rect(0, 0, 210, 15, "F");

  doc.setTextColor(255, 255, 255);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(12);
  doc.text("MATERIAL QUANTITIES & ROOM DETAIL SUMMARY", 15, 10);

  doc.setTextColor(31, 41, 55);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(11);
  doc.text("1. Bill of Quantities (BoQ) Material List", 15, 26);

  // Render Table of Materials
  let tableY = 32;
  // Header line
  doc.setFillColor(243, 244, 246);
  doc.rect(15, tableY, 180, 8, "F");
  doc.setTextColor(55, 65, 81);
  doc.setFontSize(8.5);
  doc.setFont("Helvetica", "bold");
  doc.text("MATERIAL DESCRIPTION", 18, tableY + 5.5);
  doc.text("ESTIMATED QTY / UNIT", 100, tableY + 5.5);
  doc.text("MARKET RATE (PKR)", 140, tableY + 5.5);
  doc.text("TOTAL (PKR)", 172, tableY + 5.5);
  tableY += 8;

  doc.setFont("Helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(17, 24, 39);

  design.materials.forEach((mat: MaterialItem) => {
    doc.line(15, tableY, 195, tableY); // cell divider line
    
    doc.text(mat.name, 18, tableY + 5.5);
    doc.text(`${mat.quantity.toLocaleString()} ${mat.unit}`, 100, tableY + 5.5);
    doc.text(`PKR ${mat.rate.toLocaleString()}`, 140, tableY + 5.5);
    doc.text(`PKR ${mat.totalPrice.toLocaleString()}`, 172, tableY + 5.5);

    tableY += 8;
  });

  // Architectural Recommendations Summary
  tableY += 6;
  doc.setTextColor(31, 41, 55);
  doc.setFont("Helvetica", "bold");
  doc.setFontSize(11);
  doc.text("2. Key Architectural Construction Recommendations", 15, tableY);
  tableY += 6;

  doc.setFont("Helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(55, 65, 81);

  design.aiFeedback.recommendations.forEach((rec, idx) => {
    // bullet card bg
    doc.setFillColor(249, 250, 251);
    doc.rect(15, tableY, 180, 8, "F");
    
    // Draw dot
    doc.setFillColor(16, 185, 129); // Green bullets
    doc.circle(18, tableY + 4, 1, "F");

    doc.text(rec, 22, tableY + 5);
    tableY += 10;
  });

  // Disclaimer and designer footers
  tableY += 4;
  doc.setDrawColor(243, 244, 246);
  doc.setFillColor(249, 250, 251);
  doc.rect(15, tableY, 180, 16, "FD");

  doc.setTextColor(107, 114, 128);
  doc.setFontSize(7.5);
  doc.setFont("Helvetica", "italic");
  const disclosure = "Disclaimer: Calculations details are generated by smart algorithms matching market prices in Pakistan. Actual site conditions, concrete mix designs, contractor overheads, and design modifications may require slightly adjusted quantities.";
  doc.text(doc.splitTextToSize(disclosure, 172), 18, tableY + 5);

  // --- Footer on Page 2 ---
  doc.setDrawColor(229, 231, 235);
  doc.line(15, 275, 195, 275);

  doc.setTextColor(156, 163, 175);
  doc.setFontSize(8.5);
  doc.setFont("Helvetica", "bold");
  doc.text("DESIGNED BY MR MUHAMMAD USMAN AWAN", 15, 282);
  doc.setFont("Helvetica", "normal");
  doc.text("Page 2 of 2", 185, 282);

  // Trigger Save download
  doc.save(`${design.title.replace(/\s+/g, "_")}_Layout_Report.pdf`);
};
