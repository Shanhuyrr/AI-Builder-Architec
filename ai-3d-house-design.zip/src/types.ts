export enum ArchitecturalStyle {
  MODERN = "Modern",
  TRADITIONAL = "Traditional",
  LUXURY = "Luxury"
}

export type PlotSizeUnit = "marla" | "kanal" | "sqft";

export interface PlotSize {
  value: number;
  unit: PlotSizeUnit;
  widthFt: number;
  lengthFt: number;
}

export interface RoomLayout {
  id: string;
  name: string;
  type: 'bedroom' | 'bathroom' | 'kitchen' | 'lounge' | 'garage' | 'stairs' | 'patio' | 'lawn' | 'porch';
  floor: number; // 0 = Ground, 1 = First, 2 = Second
  x: number; // relative grid coordinates (feet)
  y: number; // relative grid coordinates (feet)
  width: number; // in feet
  height: number; // in feet
  color?: string; // background visual hex representing room type
}

export interface MaterialItem {
  name: string;
  quantity: number;
  unit: string;
  rate: number; // rate per unit
  totalPrice: number;
  icon?: string;
  category: 'structural' | 'finishing' | 'fittings';
}

export interface CostCategory {
  name: string;
  amount: number;
  percentage: number;
  color: string;
}

export interface CostBreakdown {
  totalCost: number;
  materialCost: number;
  laborCost: number;
  categories: CostCategory[];
}

export interface AIArchitecturalFeedback {
  description: string;
  merits: string[];
  recommendations: string[];
  ventilationRating: number; // 1-10
  spaceEfficiencyRating: number; // 1-10
}

export interface HouseDesign {
  id: string;
  title: string;
  plotSize: PlotSize;
  floorsCount: number;
  budgetPKR: number; // In Rupees
  style: ArchitecturalStyle;
  rooms: RoomLayout[];
  materials: MaterialItem[];
  costBreakdown: CostBreakdown;
  aiFeedback: AIArchitecturalFeedback;
  createdAt: string;
}

export interface SavedDesign {
  id: string;
  design: HouseDesign;
  note?: string;
  savedAt: string;
}
