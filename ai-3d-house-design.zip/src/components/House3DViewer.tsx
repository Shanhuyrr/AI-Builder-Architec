import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { HouseDesign, RoomLayout } from "../types";
import { Compass, RotateCw, ZoomIn, ZoomOut, Eye, Sun, Moon, Sparkles, Navigation } from "lucide-react";

interface House3DViewerProps {
  design: HouseDesign;
  activeFloor: number; // 0 = Ground, 1 = First, 2 = Second, -1 = All Floors (3D)
}

type LightMode = "day" | "sunset" | "night";
type ViewMode = "solid" | "glass" | "wireframe";

export function House3DViewer({ design, activeFloor }: House3DViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [lightMode, setLightMode] = useState<LightMode>("day");
  const [viewMode, setViewMode] = useState<ViewMode>("solid");
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [focusedRoomId, setFocusedRoomId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Keep references for animation loop and interaction
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const houseGroupRef = useRef<THREE.Group | null>(null);
  const animationFrameId = useRef<number | null>(null);

  // Drag interaction states
  const isDragging = useRef(false);
  const previousMousePosition = useRef({ x: 0, y: 0 });
  const cameraRotation = useRef({ theta: Math.PI / 4, phi: Math.PI / 3, radius: 45 });

  // 1. Scene Initialization and setup
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    try {
      // Create Scene
      const scene = new THREE.Scene();
      sceneRef.current = scene;

      // Create Camera
      const camera = new THREE.PerspectiveCamera(
        45,
        containerRef.current.clientWidth / containerRef.current.clientHeight,
        0.1,
        1000
      );
      cameraRef.current = camera;
      updateCameraPosition();

      // Create Renderer with antialiasing and shadow support
      const renderer = new THREE.WebGLRenderer({
        canvas: canvasRef.current,
        antialias: true,
        alpha: true,
      });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      rendererRef.current = renderer;

      // Group for holding the whole house
      const houseGroup = new THREE.Group();
      scene.add(houseGroup);
      houseGroupRef.current = houseGroup;

      // Ground/Plot reference grid helper
      const gridHelper = new THREE.GridHelper(100, 100, 0x8b5cf6, 404040);
      gridHelper.position.y = -0.1;
      scene.add(gridHelper);

      // Setup lighting and environment based on selection
      applyLighting(scene, lightMode);

      // Build the actual 3D house structure
      buildHouseGeometry();

      // Setup Resize Observer for robust canvas scaling
      const resizeObserver = new ResizeObserver((entries) => {
        if (!entries || entries.length === 0) return;
        const entry = entries[0];
        const width = entry.contentRect.width;
        const height = entry.contentRect.height;
        if (cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = width / height;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(width, height);
        }
      });
      resizeObserver.observe(containerRef.current);

      // Start rendering animation loop
      const animate = () => {
        animationFrameId.current = requestAnimationFrame(animate);

        // Auto rotation when enabled & not dragging
        if (autoRotate && !isDragging.current) {
          cameraRotation.current.theta += 0.003;
          updateCameraPosition();
        }

        if (rendererRef.current && sceneRef.current && cameraRef.current) {
          rendererRef.current.render(sceneRef.current, cameraRef.current);
        }
      };
      animate();

      return () => {
        resizeObserver.disconnect();
        if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
        renderer.dispose();
      };
    } catch (err: any) {
      console.error("WebGL error:", err);
      setErrorMessage("Could not initialize 3D viewer. Check webgl or browser version.");
    }
  }, [design]);

  // Handle updates to viewMode or activeFloor without re-creating scene
  useEffect(() => {
    buildHouseGeometry();
  }, [activeFloor, viewMode, focusedRoomId]);

  // Handle lighting transitions
  useEffect(() => {
    if (sceneRef.current) {
      applyLighting(sceneRef.current, lightMode);
    }
  }, [lightMode]);

  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraRotation.current;

    // Convert spherical coordinates to Cartesian
    const x = radius * Math.sin(phi) * Math.sin(theta);
    const y = radius * Math.cos(phi);
    const z = radius * Math.sin(phi) * Math.cos(theta);

    cameraRef.current.position.set(x, y, z);
    cameraRef.current.lookAt(0, 4, 0);
  };

  // 2. Light environment setup
  const applyLighting = (scene: THREE.Scene, mode: LightMode) => {
    // Remove existing lights
    const existingLights = scene.getObjectsByProperty("type", "DirectionalLight");
    const existingAmbient = scene.getObjectsByProperty("type", "AmbientLight");
    const existingPoint = scene.getObjectsByProperty("type", "PointLight");

    existingLights.forEach((light) => scene.remove(light));
    existingAmbient.forEach((light) => scene.remove(light));
    existingPoint.forEach((light) => scene.remove(light));

    let ambientColor = 0xffffff;
    let ambientIntensity = 0.6;
    let dirColor = 0xffffff;
    let dirIntensity = 1.0;
    let skyColor = 0xdbeafe; // light blue sky

    switch (mode) {
      case "sunset":
        ambientColor = 0xfdba74; // warm peach
        ambientIntensity = 0.5;
        dirColor = 0xf97316; // vibrant orange
        dirIntensity = 1.3;
        skyColor = 0xfef3c7;
        break;
      case "night":
        ambientColor = 0x4f46e5; // deep indigo purple
        ambientIntensity = 0.25;
        dirColor = 0x1e1b4b;
        dirIntensity = 0.3;
        skyColor = 0x030712;
        break;
      case "day":
      default:
        ambientColor = 0xf8fafc;
        ambientIntensity = 0.65;
        dirColor = 0xffffff;
        dirIntensity = 1.1;
        skyColor = 0xf1f5f9;
        break;
    }

    // Set background colour
    scene.background = new THREE.Color(skyColor);

    const ambientLight = new THREE.AmbientLight(ambientColor, ambientIntensity);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(dirColor, dirIntensity);
    dirLight.position.set(20, 40, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    // Warm accents inside for cool nights
    if (mode === "night") {
      const yellowAccent = new THREE.PointLight(0xf59e0b, 1.8, 30);
      yellowAccent.position.set(0, 8, 0);
      scene.add(yellowAccent);

      const purpleAccent = new THREE.PointLight(0xa855f7, 2, 40);
      purpleAccent.position.set(5, 4, 10);
      scene.add(purpleAccent);
    }
  };

  // Helper: Create stylized interior furniture models using standard Three.js geometry
  const createStylizedFurniture = (room: RoomLayout, rx: number, rz: number, rfloorY: number) => {
    const furGroup = new THREE.Group();

    // Scale down items slightly to look appropriate
    const rw = room.width * 0.45;
    const rlen = room.height * 0.45;

    // Room center positioning
    furGroup.position.set(rx, rfloorY, rz);

    if (room.type === "bedroom") {
      // 1. Bed structure: bedframe + dynamic pillow + blanket
      const frameGeom = new THREE.BoxGeometry(3.5, 0.4, 4.5);
      const frameMat = new THREE.MeshStandardMaterial({ color: 0x4b5563 }); // Dark grey wood
      const bedFrame = new THREE.Mesh(frameGeom, frameMat);
      bedFrame.position.y = 0.2;
      bedFrame.castShadow = true;
      bedFrame.receiveShadow = true;
      furGroup.add(bedFrame);

      // Pillow
      const pillowGeom = new THREE.BoxGeometry(2.6, 0.18, 1);
      const pillowMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
      const pillow = new THREE.Mesh(pillowGeom, pillowMat);
      pillow.position.set(0, 0.45, -1.6);
      furGroup.add(pillow);

      // Blanket/sheet accent
      const coverGeom = new THREE.BoxGeometry(3.6, 0.42, 3.2);
      const coverMat = new THREE.MeshStandardMaterial({ color: 0x9333ea }); // Gorgeous Purple Theme Blanket!
      const cover = new THREE.Mesh(coverGeom, coverMat);
      cover.position.set(0, 0.21, 0.6);
      furGroup.add(cover);

    } else if (room.type === "lounge") {
      // 2. Corner Sofa Arrangement + Center Table
      const sofaBaseGeom = new THREE.BoxGeometry(5, 0.4, 1.4);
      const sofaMat = new THREE.MeshStandardMaterial({ color: 0x111827 }); // Charcoal
      const sofaLong = new THREE.Mesh(sofaBaseGeom, sofaMat);
      sofaLong.position.set(0, 0.2, -1.5);
      sofaLong.castShadow = true;
      furGroup.add(sofaLong);

      // Backrest
      const backGeom = new THREE.BoxGeometry(5, 1.2, 0.4);
      const backLong = new THREE.Mesh(backGeom, sofaMat);
      backLong.position.set(0, 0.60, -2.0);
      furGroup.add(backLong);

      // Center coffee table
      const tableGeom = new THREE.BoxGeometry(2.2, 0.6, 1.4);
      const tableMat = new THREE.MeshStandardMaterial({ color: 0x374151 });
      const coffeeTable = new THREE.Mesh(tableGeom, tableMat);
      coffeeTable.position.set(0, 0.3, 0);
      coffeeTable.castShadow = true;
      furGroup.add(coffeeTable);

    } else if (room.type === "kitchen") {
      // 3. Kitchen Counter (Island style)
      const counterGeom = new THREE.BoxGeometry(1.5, 1.7, 4.5);
      const counterMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.1 }); // White clean marble look
      const counter = new THREE.Mesh(counterGeom, counterMat);
      counter.position.set(-1.2, 0.85, 0);
      counter.castShadow = true;
      furGroup.add(counter);

      // Metal sink details
      const sinkGeom = new THREE.BoxGeometry(0.8, 0.05, 1.2);
      const sinkMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, metalness: 0.9 });
      const sink = new THREE.Mesh(sinkGeom, sinkMat);
      sink.position.set(-1.2, 1.71, -0.6);
      furGroup.add(sink);

    } else if (room.type === "bathroom") {
      // 4. Toilet Commode + Sink box
      const tubGeom = new THREE.BoxGeometry(1.6, 1.2, 3.2);
      const whiteCeramic = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 });
      const tub = new THREE.Mesh(tubGeom, whiteCeramic);
      tub.position.set(-0.8, 0.6, 0);
      furGroup.add(tub);

      // Commode
      const toiletGeom = new THREE.BoxGeometry(1, 0.9, 1.4);
      const toilet = new THREE.Mesh(toiletGeom, whiteCeramic);
      toilet.position.set(1.1, 0.45, 0.8);
      furGroup.add(toilet);

    } else if (room.type === "garage") {
      // 5. Stylized modern luxury sports sedan inside garage!
      const bodyGeom = new THREE.BoxGeometry(4.2, 0.8, 8.5);
      const carColor = new THREE.MeshStandardMaterial({ color: 0x9333ea, metalness: 0.7, roughness: 0.2 }); // Cool purple body car!
      const carBody = new THREE.Mesh(bodyGeom, carColor);
      carBody.position.set(0, 0.5, 0);
      carBody.castShadow = true;
      furGroup.add(carBody);

      // Windshield
      const cabinGeom = new THREE.BoxGeometry(3.6, 0.7, 4);
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x111827, transparent: true, opacity: 0.85 });
      const cabin = new THREE.Mesh(cabinGeom, glassMat);
      cabin.position.set(0, 1.15, -0.5);
      furGroup.add(cabin);

      // Wheels
      const wheelGeom = new THREE.CylinderGeometry(0.48, 0.48, 0.4, 16);
      const rubberMat = new THREE.MeshStandardMaterial({ color: 0x111827 });
      wheelGeom.rotateZ(Math.PI / 2);

      const positions = [
        [-2.0, 0.2, -2.5],
        [2.0, 0.2, -2.5],
        [-2.0, 0.2, 2.5],
        [2.0, 0.2, 2.5]
      ];
      positions.forEach(([wx, wy, wz]) => {
        const wheel = new THREE.Mesh(wheelGeom, rubberMat);
        wheel.position.set(wx, wy, wz);
        furGroup.add(wheel);
      });

    } else if (room.type === "lawn" || room.type === "patio") {
      // 6. Bushes or custom plants
      const potGeom = new THREE.CylinderGeometry(0.6, 0.4, 0.8, 8);
      const potMat = new THREE.MeshStandardMaterial({ color: 0x78350f });
      const pot = new THREE.Mesh(potGeom, potMat);
      pot.position.y = 0.4;
      furGroup.add(pot);

      // Bushes
      const leafGeom = new THREE.SphereGeometry(0.9, 8, 8);
      const leafMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.9 });
      
      const leafPositions = [
        [0, 1.0, 0],
        [-0.3, 1.4, 0.2],
        [0.2, 1.5, -0.2]
      ];
      leafPositions.forEach(([lx, ly, lz]) => {
        const foliage = new THREE.Mesh(leafGeom, leafMat);
        foliage.position.set(lx, ly, lz);
        furGroup.add(foliage);
      });
    }

    return furGroup;
  };

  // 3. Build whole house layout
  const buildHouseGeometry = () => {
    if (!houseGroupRef.current) return;

    // Clear previous children
    while (houseGroupRef.current.children.length > 0) {
      houseGroupRef.current.remove(houseGroupRef.current.children[0]);
    }

    const { widthFt, lengthFt } = design.plotSize;
    
    // Scale factor to map feet perfectly to Three.js coordinates
    // We scale down so a 30x60ft house is roughly 15x30 units in 3D
    const scale = 0.55;
    const floorHeight = 10 * scale; // 10 ft height per floor

    // Translate coordinates so center of plot aligns back with (0, y, 0)
    const tx = -(widthFt / 2) * scale;
    const tz = -(lengthFt / 2) * scale;

    // Determine opacity/materials based on viewMode
    let materialOpacity = 1.0;
    let isWireframe = false;
    let roomRoughness = 0.5;

    if (viewMode === "glass") {
      materialOpacity = 0.4;
      roomRoughness = 0.1;
    } else if (viewMode === "wireframe") {
      isWireframe = true;
    }

    // Material options
    const wallColor = viewMode === "glass" ? 0xa855f7 : 0xe2e8f0; // Beautiful lavender glass vs sleek slate white
    const wallMaterial = new THREE.MeshStandardMaterial({
      color: wallColor,
      roughness: 0.4,
      transparent: viewMode === "glass",
      opacity: viewMode === "glass" ? 0.35 : 0.95,
      wireframe: isWireframe,
    });

    const windowGlassMaterial = new THREE.MeshStandardMaterial({
      color: 0x06b6d4, // Cyan blue tint glass
      transparent: true,
      opacity: 0.6,
      roughness: 0.05,
      metalness: 0.9,
    });

    const doorMaterial = new THREE.MeshStandardMaterial({
      color: 0x78350f, // rich brown oak
      roughness: 0.8,
    });

    // Outer Boundary base plate
    const baseGeom = new THREE.BoxGeometry(widthFt * scale, 0.2, lengthFt * scale);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0xf3f4f6, roughness: 1.0 }); // plot base
    const plotBase = new THREE.Mesh(baseGeom, baseMat);
    plotBase.position.set(0, -0.1, 0);
    plotBase.receiveShadow = true;
    houseGroupRef.current.add(plotBase);

    // Loop through each room in the generated design
    design.rooms.forEach((room) => {
      // If we are showing a specific floor, skip others
      if (activeFloor !== -1 && room.floor !== activeFloor) {
        return;
      }

      // Compute standard metrics
      const rWidth = room.width * scale;
      const rLength = room.height * scale;
      const rx = (room.x * scale) + (rWidth / 2) + tx;
      const rz = (room.y * scale) + (rLength / 2) + tz;
      const rfloorY = room.floor * floorHeight;

      // Determine focus state coloration
      const isFocused = focusedRoomId === room.id;
      const roomBaseColor = isFocused ? "#c084fc" : (room.color || "#e2e8f0"); // Highlight purple when active!

      // --- Draw Floor Slab for the Room ---
      const slabGeom = new THREE.BoxGeometry(rWidth, 0.4, rLength);
      const slabMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(roomBaseColor),
        roughness: roomRoughness,
        transparent: viewMode === "glass",
        opacity: viewMode === "glass" ? 0.4 : 1.0,
        wireframe: isWireframe,
      });

      const slabMesh = new THREE.Mesh(slabGeom, slabMat);
      slabMesh.position.set(rx, rfloorY + 0.1, rz);
      slabMesh.receiveShadow = true;
      slabMesh.castShadow = true;
      houseGroupRef.current!.add(slabMesh);

      // --- Draw Walls ---
      // We will place walls (thick boxes) at the four boundaries of the room slab
      const wallThickness = 0.35;
      const wHeight = floorHeight - 0.4;
      const wallY = rfloorY + 0.2 + (wHeight / 2);

      // 1. South Wall
      const wallSouthGeom = new THREE.BoxGeometry(rWidth, wHeight, wallThickness);
      const wallSouth = new THREE.Mesh(wallSouthGeom, wallMaterial);
      wallSouth.position.set(rx, wallY, rz + (rLength / 2));
      wallSouth.castShadow = true;
      houseGroupRef.current!.add(wallSouth);

      // 2. North Wall
      const wallNorthGeom = new THREE.BoxGeometry(rWidth, wHeight, wallThickness);
      const wallNorth = new THREE.Mesh(wallNorthGeom, wallMaterial);
      wallNorth.position.set(rx, wallY, rz - (rLength / 2));
      wallNorth.castShadow = true;
      houseGroupRef.current!.add(wallNorth);

      // 3. West Wall
      const wallWestGeom = new THREE.BoxGeometry(wallThickness, wHeight, rLength);
      const wallWest = new THREE.Mesh(wallWestGeom, wallMaterial);
      wallWest.position.set(rx - (rWidth / 2), wallY, rz);
      wallWest.castShadow = true;
      houseGroupRef.current!.add(wallWest);

      // 4. East Wall
      const wallEastGeom = new THREE.BoxGeometry(wallThickness, wHeight, rLength);
      const wallEast = new THREE.Mesh(wallEastGeom, wallMaterial);
      wallEast.position.set(rx + (rWidth / 2), wallY, rz);
      wallEast.castShadow = true;
      houseGroupRef.current!.add(wallEast);

      // --- Draw Doors and Windows in exterior walls ---
      // Only do this in non-wireframe mode for cleaner aesthetics
      if (viewMode !== "wireframe") {
        // Place stylized simple window slots on exterior facing spots (e.g. rear or front sides of the floor layout)
        if (room.y === 0 || (room.y + room.height) === lengthFt) {
          // Exterior facing wall (North or South) -> place beautiful glass windows
          const winGeom = new THREE.BoxGeometry(rWidth * 0.5, wHeight * 0.5, wallThickness * 1.5);
          const winMesh = new THREE.Mesh(winGeom, windowGlassMaterial);
          const posZ = room.y === 0 ? rz - (rLength / 2) : rz + (rLength / 2);
          winMesh.position.set(rx, wallY + 0.5, posZ);
          houseGroupRef.current!.add(winMesh);
        }

        // Add a beautiful dark oak bedroom / bathroom door representation
        if (room.type === "bedroom" || room.type === "bathroom" || room.type === "kitchen") {
          const doorGeom = new THREE.BoxGeometry(wallThickness * 2, wHeight * 0.8, 2 * scale);
          const doorMesh = new THREE.Mesh(doorGeom, doorMaterial);
          // place inside at corner slot
          doorMesh.position.set(rx - (rWidth / 2), rfloorY + 0.2 + (wHeight * 0.8 / 2), rz - (rLength / 4));
          houseGroupRef.current!.add(doorMesh);
        }
      }

      // --- Standalone interior furniture components ---
      if (viewMode !== "wireframe" && viewMode !== "glass") {
        const furniture = createStylizedFurniture(room, rx, rz, rfloorY + 0.3);
        houseGroupRef.current!.add(furniture);
      }
    });

    // If displaying all floors, draw a gorgeous light transparent roof at the topmost floor height
    if (activeFloor === -1 && viewMode !== "wireframe") {
      const topFloorNum = design.floorsCount;
      const roofY = topFloorNum * floorHeight;
      const roofGeom = new THREE.BoxGeometry((widthFt - 4) * scale, 0.4, (lengthFt - 4) * scale);
      
      const roofColor = viewMode === "glass" ? 0xa855f7 : 0x7c3aed; // Accent Purple Roof structures!
      const roofMat = new THREE.MeshStandardMaterial({
        color: roofColor,
        roughness: 0.1,
        transparent: true,
        opacity: 0.5,
      });

      const roof = new THREE.Mesh(roofGeom, roofMat);
      roof.position.set(0, roofY, 0);
      roof.castShadow = true;
      houseGroupRef.current!.add(roof);

      // Add a structural slope to the roof if style is traditional
      if (design.style === "Traditional") {
        const pyramidGeom = new THREE.ConeGeometry((widthFt - 8) * scale, 3, 4);
        pyramidGeom.rotateY(Math.PI / 4);
        const pyramidMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.8 }); // Red ceramic tile look
        const pyramidRoof = new THREE.Mesh(pyramidGeom, pyramidMat);
        pyramidRoof.position.set(0, roofY + 1.5, 0);
        pyramidRoof.castShadow = true;
        houseGroupRef.current!.add(pyramidRoof);
      }
    }
  };

  // 4. Mouse Drag Navigation and Camera controls
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;

    const deltaX = e.clientX - previousMousePosition.current.x;
    const deltaY = e.clientY - previousMousePosition.current.y;

    previousMousePosition.current = { x: e.clientX, y: e.clientY };

    // Update spherical coordinates
    cameraRotation.current.theta -= deltaX * 0.008;
    cameraRotation.current.phi = Math.max(
      0.1,
      Math.min(Math.PI / 2 - 0.05, cameraRotation.current.phi - deltaY * 0.008)
    );

    updateCameraPosition();
  };

  const handleMouseUpOrLeave = () => {
    isDragging.current = false;
  };

  const zoomIn = () => {
    cameraRotation.current.radius = Math.max(10, cameraRotation.current.radius - 4);
    updateCameraPosition();
  };

  const zoomOut = () => {
    cameraRotation.current.radius = Math.min(90, cameraRotation.current.radius + 4);
    updateCameraPosition();
  };

  // Teleport walkthrough focus effect
  const handleRoomFocus = (roomId: string) => {
    setFocusedRoomId(roomId);
    const room = design.rooms.find(r => r.id === roomId);
    if (!room || !cameraRef.current) return;

    const scale = 0.55;
    const floorHeight = 10 * scale;
    const rx = (room.x * scale) + (room.width * scale / 2) - (design.plotSize.widthFt / 2) * scale;
    const rz = (room.y * scale) + (room.height * scale / 2) - (design.plotSize.lengthFt / 2) * scale;
    const rfloorY = room.floor * floorHeight;

    // Direct camera close up on room coordinates
    cameraRotation.current.radius = 20;
    cameraRef.current.position.set(rx + 8, rfloorY + 7, rz + 8);
    cameraRef.current.lookAt(rx, rfloorY + 2, rz);
    setAutoRotate(false);
  };

  const resetCamera = () => {
    setFocusedRoomId(null);
    cameraRotation.current = { theta: Math.PI / 4, phi: Math.PI / 3, radius: 45 };
    updateCameraPosition();
  };

  return (
    <div id="viewer3d_container" className="flex flex-col h-full bg-slate-100 rounded-3xl overflow-hidden border border-gray-200 shadow-sm relative">
      {/* Visual Controls / Toolbar */}
      <div className="absolute top-4 left-4 right-4 z-10 flex flex-wrap gap-2 items-center justify-between">
        <div className="flex gap-2">
          <span className="px-3 py-1 bg-white/90 backdrop-blur rounded-full text-[10px] font-bold text-slate-700 shadow-sm flex items-center gap-1.5 border border-slate-200">
            <Compass className="w-3.5 h-3.5 text-purple-600 animate-spin" />
            3D REALISTIC ENGINE
          </span>
          {focusedRoomId && (
            <span className="px-3 py-1 bg-purple-100/90 text-purple-700 backdrop-blur rounded-full text-[10px] font-bold shadow-sm">
              FOCUSING: {design.rooms.find(r => r.id === focusedRoomId)?.name}
            </span>
          )}
        </div>

        {/* Style selection */}
        <div className="flex gap-1.5 bg-white/90 backdrop-blur p-1 rounded-full shadow-sm border border-slate-200">
          <button
            id="view_solid_btn"
            onClick={() => setViewMode("solid")}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
              viewMode === "solid" ? "bg-purple-600 text-white shadow-sm" : "text-slate-600 hover:text-purple-600"
            }`}
          >
            Realistic
          </button>
          <button
            id="view_blueprint_btn"
            onClick={() => setViewMode("glass")}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
              viewMode === "glass" ? "bg-purple-600 text-white shadow-sm" : "text-slate-600 hover:text-purple-600"
            }`}
          >
            Digital Glass
          </button>
          <button
            id="view_xray_btn"
            onClick={() => setViewMode("wireframe")}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
              viewMode === "wireframe" ? "bg-purple-600 text-white shadow-sm" : "text-slate-600 hover:text-purple-600"
            }`}
          >
            X-Ray Grid
          </button>
        </div>
      </div>

      {/* Lighting Presets */}
      <div className="absolute top-18 right-4 z-10 flex flex-col gap-2">
        <button
          id="light_day_btn"
          title="Daytime Sun"
          onClick={() => setLightMode("day")}
          className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur shadow-sm transition-all ${
            lightMode === "day" ? "bg-amber-100 text-amber-600 border border-amber-300" : "bg-white/80 text-slate-500 border border-slate-200 hover:bg-white"
          }`}
        >
          <Sun className="w-4 h-4" />
        </button>
        <button
          id="light_sunset_btn"
          title="Golden Sunset"
          onClick={() => setLightMode("sunset")}
          className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur shadow-sm transition-all ${
            lightMode === "sunset" ? "bg-orange-100 text-orange-600 border border-orange-300" : "bg-white/80 text-slate-500 border border-slate-200 hover:bg-white"
          }`}
        >
          <Sparkles className="w-4 h-4" />
        </button>
        <button
          id="light_night_btn"
          title="Ambient Night"
          onClick={() => setLightMode("night")}
          className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur shadow-sm transition-all ${
            lightMode === "night" ? "bg-indigo-900 text-purple-300 border border-indigo-700" : "bg-white/80 text-slate-500 border border-slate-200 hover:bg-white"
          }`}
        >
          <Moon className="w-4 h-4" />
        </button>
      </div>

      {/* Interactive room list trigger for focus */}
      <div className="absolute left-4 bottom-4 z-10 max-w-xs max-h-48 overflow-y-auto bg-white/90 backdrop-blur rounded-2xl p-3 shadow-md border border-slate-200 hidden md:block">
        <div className="text-[10px] font-extrabold uppercase text-slate-400 mb-1.5 tracking-wider">Quick Room Teleport</div>
        <div className="flex flex-wrap gap-1.5">
          {design.rooms
            .filter((r) => activeFloor === -1 || r.floor === activeFloor)
            .map((room) => (
              <button
                key={room.id}
                onClick={() => handleRoomFocus(room.id)}
                className={`px-2 py-1 rounded text-[10px] font-bold uppercase transition-all ${
                  focusedRoomId === room.id
                    ? "bg-purple-600 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-purple-50 hover:text-purple-600"
                }`}
              >
                {room.name.split(" ")[0]}
              </button>
            ))}
        </div>
      </div>

      {/* Error / WebGL fallback */}
      {errorMessage ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-slate-900 text-slate-300">
          <Compass className="w-12 h-12 text-slate-500 mb-3 animate-bounce" />
          <h4 className="text-md font-bold mb-1">Interactive 3D Render</h4>
          <p className="text-xs max-w-sm text-slate-400">{errorMessage}</p>
        </div>
      ) : (
        /* Real Canvas viewport */
        <div
          ref={containerRef}
          className="flex-1 relative cursor-grab active:cursor-grabbing overflow-hidden h-full"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUpOrLeave}
          onMouseLeave={handleMouseUpOrLeave}
        >
          <canvas ref={canvasRef} className="w-full h-full block" />
        </div>
      )}

      {/* Bottom Camera bar */}
      <div className="absolute bottom-4 right-4 z-10 flex gap-2 bg-white/95 backdrop-blur px-3 py-2 rounded-2xl shadow-lg border border-slate-100">
        <button
          id="cam_zoomin_btn"
          title="Zoom In"
          onClick={zoomIn}
          className="w-8 h-8 rounded-xl bg-slate-100 text-slate-600 hover:bg-purple-50 hover:text-purple-600 transition-all flex items-center justify-center"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          id="cam_zoomout_btn"
          title="Zoom Out"
          onClick={zoomOut}
          className="w-8 h-8 rounded-xl bg-slate-100 text-slate-600 hover:bg-purple-50 hover:text-purple-600 transition-all flex items-center justify-center"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          id="cam_rotate_btn"
          title="Toggle Auto Rotation"
          onClick={() => setAutoRotate(!autoRotate)}
          className={`w-8 h-8 rounded-xl transition-all flex items-center justify-center ${
            autoRotate ? "bg-purple-600 text-white shadow-sm shadow-purple-200" : "bg-slate-100 text-slate-600 hover:bg-purple-50"
          }`}
        >
          <RotateCw className={`w-4 h-4 ${autoRotate ? "animate-spin" : ""}`} />
        </button>
        <button
          id="cam_reset_btn"
          title="Reset Camera Preset"
          onClick={resetCamera}
          className="w-8 h-8 rounded-xl bg-slate-100 text-slate-600 hover:bg-purple-50 hover:text-purple-600 transition-all flex items-center justify-center"
        >
          <Navigation className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
