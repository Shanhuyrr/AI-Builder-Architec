import React, { useState } from "react";
import { HouseDesign, RoomLayout } from "../types";
import { Plus, Trash2, Edit3, Ruler, Compass, Sparkles, Check, ChevronDown, CheckCircle } from "lucide-react";

interface House2DBlueprintProps {
  design: HouseDesign;
  activeFloor: number; // 0 = Ground, 1 = First, 2 = Second
  onUpdateRooms: (updatedRooms: RoomLayout[]) => void;
}

export function House2DBlueprint({ design, activeFloor, onUpdateRooms }: House2DBlueprintProps) {
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  
  // States for adding or editing a custom room
  const [isAddingRoom, setIsAddingRoom] = useState(false);
  const [newRoomName, setNewRoomName] = useState("");
  const [newRoomType, setNewRoomType] = useState<RoomLayout["type"]>("bedroom");
  const [newRoomX, setNewRoomX] = useState(0);
  const [newRoomY, setNewRoomY] = useState(0);
  const [newRoomW, setNewRoomW] = useState(12);
  const [newRoomH, setNewRoomH] = useState(12);

  const { widthFt, lengthFt } = design.plotSize;
  const filteredRooms = design.rooms.filter((room) => room.floor === activeFloor);

  // Colors for room types
  const getRoomColor = (type: RoomLayout["type"]) => {
    switch (type) {
      case "bedroom": return "bg-blue-50 border-blue-250 text-blue-800";
      case "bathroom": return "bg-sky-50 border-sky-250 text-sky-800";
      case "kitchen": return "bg-amber-50 border-amber-250 text-amber-800";
      case "lounge": return "bg-purple-50 border-purple-250 text-purple-800";
      case "garage": return "bg-slate-100 border-slate-350 text-slate-800";
      case "stairs": return "bg-pink-50 border-pink-250 text-pink-800";
      case "patio": return "bg-zinc-100 border-zinc-250 text-zinc-800";
      case "lawn": return "bg-emerald-50 border-emerald-250 text-emerald-800";
      default: return "bg-gray-50 border-gray-250 text-gray-800";
    }
  };

  const getRoomHex = (type: RoomLayout["type"]) => {
    switch (type) {
      case "bedroom": return "#3B82F6";
      case "bathroom": return "#06B6D4";
      case "kitchen": return "#F59E0B";
      case "lounge": return "#7C3AED";
      case "garage": return "#4B5563";
      case "stairs": return "#EC4899";
      case "patio": return "#9CA3AF";
      case "lawn": return "#10B981";
      default: return "#6B7280";
    }
  };

  // Handle room parameter change
  const handleRoomSizeChange = (roomId: string, field: "width" | "height" | "x" | "y", value: number) => {
    const updated = design.rooms.map((room) => {
      if (room.id === roomId) {
        // Enforce basic architectural boundary constraints
        let val = Math.max(2, Math.min(60, value));
        return { ...room, [field]: val };
      }
      return room;
    });
    onUpdateRooms(updated);
  };

  // Add room action
  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName) return;

    const newRoom: RoomLayout = {
      id: "room_" + Date.now(),
      name: newRoomName,
      type: newRoomType,
      floor: activeFloor,
      x: Number(newRoomX),
      y: Number(newRoomY),
      width: Number(newRoomW),
      height: Number(newRoomH),
      color: getRoomHex(newRoomType),
    };

    onUpdateRooms([...design.rooms, newRoom]);
    setIsAddingRoom(false);
    // Reset defaults
    setNewRoomName("");
    setNewRoomW(12);
    setNewRoomH(12);
  };

  // Delete Room action
  const handleDeleteRoom = (roomId: string) => {
    const updated = design.rooms.filter((room) => room.id !== roomId);
    onUpdateRooms(updated);
    if (selectedRoomId === roomId) {
      setSelectedRoomId(null);
    }
  };

  const selectedRoom = design.rooms.find((r) => r.id === selectedRoomId);

  return (
    <div id="blueprint2d_main_card" className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Ruler className="text-purple-600 w-5 h-5" />
            2D Floor Plan layout explorer
          </h3>
          <p className="text-xs text-slate-500">
            Click on any room to scale dimensions, relocate coordinates, and optimize your floor draft layout.
          </p>
        </div>
        <button
          id="add_new_room_btn"
          onClick={() => setIsAddingRoom(!isAddingRoom)}
          className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 transition-all rounded-xl self-start"
        >
          <Plus className="w-4 h-4" /> Add Custom Space
        </button>
      </div>

      {/* Adding Room Box */}
      {isAddingRoom && (
        <form onSubmit={handleAddRoom} id="new_room_form" className="mb-6 p-4 bg-slate-50 rounded-2xl border border-slate-100 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 transition-all">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-600 mb-1">Space Label Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Kid's Bedroom / Study Room"
              value={newRoomName}
              onChange={(e) => setNewRoomName(e.target.value)}
              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Space Type</label>
            <select
              value={newRoomType}
              onChange={(e) => setNewRoomType(e.target.value as any)}
              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs"
            >
              <option value="bedroom">Bedroom</option>
              <option value="bathroom">Bathroom</option>
              <option value="kitchen">Kitchen</option>
              <option value="lounge">Living Lounge</option>
              <option value="garage">Car Porch / Garage</option>
              <option value="stairs">Stair Hall</option>
              <option value="lawn">Lawn & Garden</option>
              <option value="patio">Open Patio Yard</option>
            </select>
          </div>
          <div className="flex gap-2 items-end">
            <button
              type="submit"
              className="flex-1 p-2 bg-green-600 text-white font-bold rounded-lg text-xs hover:bg-green-700 transition-all"
            >
              Confirm Space
            </button>
            <button
              type="button"
              onClick={() => setIsAddingRoom(false)}
              className="p-2 bg-slate-200 text-slate-700 rounded-lg text-xs hover:bg-slate-350 transition-all"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-4 gap-2 sm:col-span-2 md:col-span-4">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-0.5">X-Pos (Ft)</label>
              <input
                type="number"
                min={0}
                max={widthFt}
                value={newRoomX}
                onChange={(e) => setNewRoomX(Number(e.target.value))}
                className="w-full p-1.5 border border-slate-200 rounded text-xs bg-white"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-0.5">Y-Pos (Ft)</label>
              <input
                type="number"
                min={0}
                max={lengthFt}
                value={newRoomY}
                onChange={(e) => setNewRoomY(Number(e.target.value))}
                className="w-full p-1.5 border border-slate-200 rounded text-xs bg-white"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-0.5">Width (Ft)</label>
              <input
                type="number"
                min={2}
                max={widthFt}
                value={newRoomW}
                onChange={(e) => setNewRoomW(Number(e.target.value))}
                className="w-full p-1.5 border border-slate-200 rounded text-xs bg-white"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-400 mb-0.5">Length (Ft)</label>
              <input
                type="number"
                min={2}
                max={lengthFt}
                value={newRoomH}
                onChange={(e) => setNewRoomH(Number(e.target.value))}
                className="w-full p-1.5 border border-slate-200 rounded text-xs bg-white"
              />
            </div>
          </div>
        </form>
      )}

      {/* Main Grid Area and Sidebar Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual Map Render */}
        <div id="layout_relative_draft" className="lg:col-span-2 border border-dashed border-slate-200 rounded-3xl p-4 bg-slate-50 flex items-center justify-center min-h-[380px] relative">
          <div className="absolute top-3 left-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-white px-2 py-1 rounded border border-slate-100">
            Plot Dimensions: {widthFt}' x {lengthFt}'
          </div>

          {/* Interactive Plot container */}
          <div
            className="w-full max-w-[400px] mb-4 bg-white border-2 border-slate-350 shadow-inner rounded-xl relative overflow-hidden transition-all"
            style={{
              aspectRatio: `${widthFt} / ${lengthFt}`,
            }}
          >
            {/* Background Grid Lines representing feet */}
            <div className="absolute inset-0 grid grid-cols-5 grid-rows-5 opacity-40 pointer-events-none">
              {Array.from({ length: 25 }).map((_, i) => (
                <div key={i} className="border-[0.5px] border-slate-100" />
              ))}
            </div>

            {/* Room Boxes drawn on absolute positions */}
            {filteredRooms.map((room) => {
              const xPercent = (room.x / widthFt) * 100;
              const yPercent = (room.y / lengthFt) * 100;
              const wPercent = (room.width / widthFt) * 100;
              const hPercent = (room.height / lengthFt) * 100;

              const isSelected = room.id === selectedRoomId;

              return (
                <button
                  key={room.id}
                  onClick={() => setSelectedRoomId(room.id)}
                  type="button"
                  className={`absolute rounded-lg border-2 p-1.5 text-left transition-all overflow-hidden flex flex-col justify-between group ${getRoomColor(
                    room.type
                  )} ${isSelected ? "ring-2 ring-purple-600 border-purple-500 scale-[0.99] z-20 shadow-md" : "hover:border-slate-500 hover:scale-[0.99] z-10"}`}
                  style={{
                    left: `${xPercent}%`,
                    top: `${yPercent}%`,
                    width: `${wPercent}%`,
                    height: `${hPercent}%`,
                  }}
                >
                  <div className="leading-tight">
                    <span className="block text-[8px] sm:text-[10px] font-black truncate">{room.name}</span>
                    <span className="block text-[7px] sm:text-[8px] opacity-75">{room.width}' x {room.height}'</span>
                  </div>
                  <span className="text-[6px] sm:text-[8px] font-mono opacity-80 mt-1 self-end truncate">
                    {Math.round(room.width * room.height)} sqft
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Room controller Panel */}
        <div id="inspector_selected_room" className="bg-slate-50 border border-slate-100 rounded-3xl p-5 flex flex-col justify-between h-full min-h-[350px]">
          {selectedRoom ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <span className="text-[10px] tracking-widest font-bold uppercase text-purple-600 block">Space Inspector</span>
                  <h4 id="inspector_title" className="text-md font-bold text-slate-800">{selectedRoom.name}</h4>
                </div>
                <button
                  id="inspector_delete_btn"
                  onClick={() => handleDeleteRoom(selectedRoom.id)}
                  type="button"
                  className="p-1.5 text-red-500 hover:text-red-700 bg-red-50 rounded-lg hover:bg-red-100 transition-all"
                  title="Remove Space"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Adjust Width Sliders */}
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                    <span>Width: {selectedRoom.width} ft</span>
                    <span className="text-slate-400">Max {widthFt} ft</span>
                  </div>
                  <input
                    type="range"
                    min={4}
                    max={widthFt}
                    value={selectedRoom.width}
                    onChange={(e) => handleRoomSizeChange(selectedRoom.id, "width", Number(e.target.value))}
                    className="w-full accent-purple-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                    <span>Length: {selectedRoom.height} ft</span>
                    <span className="text-slate-400">Max {lengthFt} ft</span>
                  </div>
                  <input
                    type="range"
                    min={4}
                    max={lengthFt}
                    value={selectedRoom.height}
                    onChange={(e) => handleRoomSizeChange(selectedRoom.id, "height", Number(e.target.value))}
                    className="w-full accent-purple-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                    <span>Horizontal Pos (X-Axis): {selectedRoom.x} ft</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(0, widthFt - selectedRoom.width)}
                    value={selectedRoom.x}
                    onChange={(e) => handleRoomSizeChange(selectedRoom.id, "x", Number(e.target.value))}
                    className="w-full accent-purple-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                    <span>Vertical Pos (Y-Axis): {selectedRoom.y} ft</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(0, lengthFt - selectedRoom.height)}
                    value={selectedRoom.y}
                    onChange={(e) => handleRoomSizeChange(selectedRoom.id, "y", Number(e.target.value))}
                    className="w-full accent-purple-600 h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>

              {/* Space statistics */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-white rounded-xl border border-slate-150">
                  <span className="block text-[9px] font-extrabold uppercase text-slate-400">Floor Covered</span>
                  <span className="text-md font-bold text-slate-800">
                    {Math.round(selectedRoom.width * selectedRoom.height)} <span className="text-xs font-semibold">sqft</span>
                  </span>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-150">
                  <span className="block text-[9px] font-extrabold uppercase text-slate-400">Plumbing Node</span>
                  <span className="text-md font-bold text-slate-800 flex items-center gap-1">
                    {selectedRoom.type === "bathroom" || selectedRoom.type === "kitchen" ? (
                      <span className="text-blue-500 text-xs font-bold font-mono">ACTIVE</span>
                    ) : (
                      <span className="text-slate-400 text-xs font-bold font-mono">NONE</span>
                    )}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <Compass className="w-8 h-8 text-slate-300 mb-2 animate-pulse" />
              <p className="text-xs font-semibold">No Space Selected</p>
              <p className="text-[10px] text-slate-400 max-w-xs mt-1">
                Select any colored room on the blueprint to toggle real-time dimensional scaling.
              </p>
            </div>
          )}

          <div className="border-t border-slate-200 pt-3 mt-4 text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-green-500" /> Real-time constraint compliance
          </div>
        </div>
      </div>
    </div>
  );
}
