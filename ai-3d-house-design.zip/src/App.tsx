import React, { useState, useEffect } from "react";
import { ArchitecturalStyle, HouseDesign, RoomLayout, MaterialItem, SavedDesign } from "./types";
import { House3DViewer } from "./components/House3DViewer";
import { House2DBlueprint } from "./components/House2DBlueprint";
import { exportDesignPDF } from "./utils/pdfExport";
import {
  Home,
  Building,
  Layers,
  Wrench,
  Sparkles,
  Download,
  Plus,
  Compass,
  DollarSign,
  CheckCircle,
  MessageCircle,
  Bookmark,
  Trash2,
  FolderOpen,
  HelpCircle,
  ChevronRight,
  Calculator,
  RefreshCw,
  Clock,
  ExternalLink,
  ArrowRight
} from "lucide-react";

export default function App() {
  // Input parameters
  const [plotValue, setPlotValue] = useState<number>(10); // 5, 10, or 20 (for 1 Kanal)
  const [floorsCount, setFloorsCount] = useState<number>(2);
  const [targetBudget, setTargetBudget] = useState<number>(15000000); // Standard 1.5 Crores
  const [prefStyle, setPrefStyle] = useState<ArchitecturalStyle>(ArchitecturalStyle.MODERN);
  const [customInstructions, setCustomInstructions] = useState<string>("");

  // System states
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [progressStep, setProgressStep] = useState<string>("");
  const [currentDesign, setCurrentDesign] = useState<HouseDesign | null>(null);
  const [activeFloor, setActiveFloor] = useState<number>(-1); // -1 = 3D solid house view, 0 = Ground, 1 = First, 2 = Second
  const [savedDesigns, setSavedDesigns] = useState<SavedDesign[]>([]);
  const [activeTab, setActiveTab] = useState<"studio" | "dashboard" | "about">("studio");
  const [materialFilterCategory, setMaterialFilterCategory] = useState<"all" | "structural" | "finishing" | "fittings">("all");

  // Material rates customization modal or active panel state ( Pakistan standard adjustments)
  const [laborRate, setLaborRate] = useState<number>(550);
  const [brickRate, setBrickRate] = useState<number>(18);
  const [cementRate, setCementRate] = useState<number>(1450);
  const [steelRate, setSteelRate] = useState<number>(260000);

  // 1. Initial Default Build on First Mount
  useEffect(() => {
    // Load saved layouts from local storage
    const stored = localStorage.getItem("awan_house_designs");
    if (stored) {
      try {
        setSavedDesigns(JSON.parse(stored));
      } catch (e) {
        console.warn("Could not read local saved designs database:", e);
      }
    }

    // Auto-generate deep default layout for 10 Marla Modern Double Storey
    handleGenerate(true);
  }, []);

  // 2. Generate Design API Call
  const handleGenerate = async (isInitial = false) => {
    setIsGenerating(true);
    setProgressStep("Initializing plot parameters...");

    // Staggered premium visual feedback messages for immersive experience
    const progressMessages = [
      "Calculating local setbacks per LDA / CDA building bylaws...",
      "Analyzing ventilation vector paths & cross-breeze ratios...",
      "Synthesizing 2D floor plans with structural stability grids...",
      "Arranging Master Bed stacks & wet areas placement...",
      "Optimizing brick counts & heavy rebar steel quantities...",
      "Calling Gemini 3.5 intelligent architectural audit pipeline...",
      "Finalizing high-fidelity 3D structural mapping meshes..."
    ];

    let messageIdx = 0;
    const interval = setInterval(() => {
      if (messageIdx < progressMessages.length) {
        setProgressStep(progressMessages[messageIdx]);
        messageIdx++;
      }
    }, 450);

    try {
      const response = await fetch("/api/generate-design", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plotSize: { value: plotValue, unit: "marla" },
          floorsCount,
          budgetPKR: targetBudget,
          style: prefStyle,
          customNotes: customInstructions
        }),
      });

      clearInterval(interval);

      if (!response.ok) {
        throw new Error("Design generation endpoint returned non-ok status");
      }

      const data = await response.json();
      
      // Inject some dynamic rate adjustments locally if user modified rates
      if (!isInitial && data.materials) {
        let updatedTotal = 0;
        const processedMaterials = data.materials.map((m: MaterialItem) => {
          let updatedRate = m.rate;
          if (m.name.includes("Bricks")) updatedRate = brickRate;
          else if (m.name.includes("Cement")) updatedRate = cementRate;
          else if (m.name.includes("Steel")) updatedRate = steelRate;
          
          const totalPrice = m.quantity * updatedRate;
          updatedTotal += totalPrice;
          return { ...m, rate: updatedRate, totalPrice };
        });

        const laborTotal = (data.plotSize.value === 5 ? 1600 : data.plotSize.value === 10 ? 3200 : 6000) * laborRate;
        const grandTotal = updatedTotal + laborTotal;
        
        data.materials = processedMaterials;
        data.costBreakdown.totalCost = grandTotal;
        data.costBreakdown.laborCost = laborTotal;
        data.costBreakdown.materialCost = updatedTotal;
        
        // Re-apportion percentages
        data.costBreakdown.categories = data.costBreakdown.categories.map((cat: any) => {
          if (cat.name.includes("Grey")) {
            const structuralSum = processedMaterials.filter((m: any) => m.category === 'structural').reduce((s: number, m: any) => s + m.totalPrice, 0);
            return { ...cat, amount: structuralSum, percentage: Number(((structuralSum / grandTotal) * 100).toFixed(1)) };
          } else if (cat.name.includes("Finishing")) {
            const finishingSum = processedMaterials.filter((m: any) => m.category !== 'structural').reduce((s: number, m: any) => s + m.totalPrice, 0);
            return { ...cat, amount: finishingSum, percentage: Number(((finishingSum / grandTotal) * 100).toFixed(1)) };
          } else {
            return { ...cat, amount: laborTotal, percentage: Number(((laborTotal / grandTotal) * 100).toFixed(1)) };
          }
        });
      }

      setCurrentDesign(data);
      setActiveFloor(-1); // Switch default view back to all-floor 3D view
    } catch (error) {
      console.error("Failed to fetch generated design:", error);
      alert("Failed to render AI Smart layout. Reverting to backup system templates.");
    } finally {
      setIsGenerating(false);
    }
  };

  // 3. User customized room updates from 2D Layout Blueprint
  const handleUpdateRooms = (updatedRooms: RoomLayout[]) => {
    if (!currentDesign) return;

    // Recalculate covered area sqft and slightly update material/labor estimations
    const groundArea = updatedRooms.filter(r => r.floor === 0 && r.type !== 'lawn').reduce((sum, r) => sum + (r.width * r.height), 0);
    const upperArea = updatedRooms.filter(r => r.floor > 0 && r.type !== 'lawn').reduce((sum, r) => sum + (r.width * r.height), 0);
    const totalCovered = groundArea + upperArea;

    // Direct proportional re-calculation
    const updateMaterials = currentDesign.materials.map((m) => {
      let calcQty = m.quantity;
      if (m.name.includes("Bricks")) calcQty = Math.round(totalCovered * 38);
      else if (m.name.includes("Cement")) calcQty = Math.round(totalCovered * 0.44);
      else if (m.name.includes("Steel")) calcQty = Number((totalCovered * 4.1 / 1000).toFixed(2));
      else if (m.name.includes("Sand")) calcQty = Math.round(totalCovered * 1.3);
      else if (m.name.includes("Crush")) calcQty = Math.round(totalCovered * 0.85);
      else {
        // Tiles or finishing paint proportional to scale area changes
        const areaRatio = totalCovered / (currentDesign.plotSize.value === 5 ? 1600 : currentDesign.plotSize.value === 10 ? 3200 : 6000);
        calcQty = Math.round(m.quantity * areaRatio);
      }

      return {
        ...m,
        quantity: calcQty,
        totalPrice: Math.round(calcQty * m.rate)
      };
    });

    const materialsSum = updateMaterials.reduce((sum, m) => sum + m.totalPrice, 0);
    const laborSum = totalCovered * laborRate;
    const totalCombined = materialsSum + laborSum;

    const updatedCategories = currentDesign.costBreakdown.categories.map((cat) => {
      if (cat.name.includes("Grey")) {
        const structuralSum = updateMaterials.filter(m => m.category === 'structural').reduce((s, m) => s + m.totalPrice, 0);
        return { ...cat, amount: structuralSum, percentage: Number(((structuralSum / totalCombined) * 100).toFixed(1)) };
      } else if (cat.name.includes("Finishing")) {
        const finishingSum = updateMaterials.filter(m => m.category !== 'structural').reduce((s, m) => s + m.totalPrice, 0);
        return { ...cat, amount: finishingSum, percentage: Number(((finishingSum / totalCombined) * 100).toFixed(1)) };
      } else {
        return { ...cat, amount: laborSum, percentage: Number(((laborSum / totalCombined) * 100).toFixed(1)) };
      }
    });

    setCurrentDesign({
      ...currentDesign,
      rooms: updatedRooms,
      materials: updateMaterials,
      costBreakdown: {
        totalCost: totalCombined,
        materialCost: materialsSum,
        laborCost: laborSum,
        categories: updatedCategories
      }
    });
  };

  // 4. Save Layout design locally to system database
  const handleSaveDesign = () => {
    if (!currentDesign) return;

    const alreadySaved = savedDesigns.some(d => d.design.id === currentDesign.id);
    if (alreadySaved) {
      alert("This project layout is already saved in your dashboard portfolio.");
      return;
    }

    const item: SavedDesign = {
      id: "saved_" + Date.now(),
      design: currentDesign,
      savedAt: new Date().toISOString()
    };

    const next = [item, ...savedDesigns];
    setSavedDesigns(next);
    localStorage.setItem("awan_house_designs", JSON.stringify(next));
    alert("Project layout successfully archived to your AI Studio dashboard portfolio!");
  };

  const handleDeleteSaved = (id: string) => {
    const next = savedDesigns.filter(d => d.id !== id);
    setSavedDesigns(next);
    localStorage.setItem("awan_house_designs", JSON.stringify(next));
  };

  // 5. Load layout design back to dashboard view editor
  const handleLoadSaved = (saved: SavedDesign) => {
    setCurrentDesign(saved.design);
    setPlotValue(saved.design.plotSize.value);
    setFloorsCount(saved.design.floorsCount);
    setTargetBudget(saved.design.budgetPKR);
    setPrefStyle(saved.design.style);
    setActiveTab("studio");
  };

  // Pakistani WhatsApp prefilled contact link
  const generateWhatsAppURI = () => {
    const textStr = currentDesign
      ? `Assalam-o-Alaikum, I am using the AI 3D House Design platform. I would like custom support for a ${currentDesign.plotSize.value} Marla ${currentDesign.style} House (Estimated Cost: PKR ${currentDesign.costBreakdown.totalCost.toLocaleString()}). Please assist me.`
      : "Hi Mr Muhammad Usman Awan, I am interested in custom package designs for my future home project.";
    return `https://wa.me/923220591711?text=${encodeURIComponent(textStr)}`;
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans select-none overflow-x-hidden text-slate-800">
      
      {/* Top Header Section */}
      <header className="h-16 px-6 lg:px-12 bg-white border-b border-gray-100 flex items-center justify-between shrink-0 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center text-white font-extrabold text-xl shadow-md cursor-pointer">
            🏠
          </div>
          <div>
            <span className="text-lg font-black tracking-tight text-slate-900">
              ARCHI<span className="text-purple-600">AI</span> Studio
            </span>
            <span className="block text-[8px] tracking-widest text-slate-400 font-extrabold uppercase -mt-1">
              By Mr Muhammad Usman Awan
            </span>
          </div>
        </div>

        {/* Multi-Tabs navigation */}
        <div className="flex gap-1 md:gap-4 text-xs font-semibold">
          <button
            id="tab_studio_btn"
            onClick={() => setActiveTab("studio")}
            className={`px-3 py-2 rounded-xl transition-all ${
              activeTab === "studio" ? "bg-purple-50 text-purple-600 font-extrabold" : "text-slate-500 hover:text-purple-600"
            }`}
          >
            Design Studio
          </button>
          <button
            id="tab_dashboard_btn"
            onClick={() => setActiveTab("dashboard")}
            className={`px-3 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
              activeTab === "dashboard" ? "bg-purple-50 text-purple-600 font-extrabold" : "text-slate-500 hover:text-purple-600"
            }`}
          >
            My Portfolio
            {savedDesigns.length > 0 && (
              <span className="w-4 h-4 bg-purple-600 text-white rounded-full text-[9px] flex items-center justify-center font-bold">
                {savedDesigns.length}
              </span>
            )}
          </button>
          <button
            id="tab_about_btn"
            onClick={() => setActiveTab("about")}
            className={`px-3 py-2 rounded-xl transition-all ${
              activeTab === "about" ? "bg-purple-50 text-purple-600 font-extrabold" : "text-slate-500 hover:text-purple-600"
            }`}
          >
            Standard Manual
          </button>
        </div>

        {/* Global actions */}
        <div className="hidden sm:flex items-center gap-3">
          {currentDesign && (
            <button
              id="export_pdf_top_btn"
              onClick={() => exportDesignPDF(currentDesign)}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-purple-700 transition-all shadow-sm"
              title="Download Schematics, BOQ, and Cost Breakdown Report"
            >
              <Download className="w-3.5 h-3.5" /> PDF Report
            </button>
          )}
          <a
            href={generateWhatsAppURI()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-all shadow-sm"
          >
            <MessageCircle className="w-3.5 h-3.5" /> Direct Support
          </a>
        </div>
      </header>

      {/* Main Container Workspace */}
      <main className="flex-1 flex flex-col">
        {activeTab === "about" && (
          <div className="max-w-4xl mx-auto p-6 md:p-12 space-y-8 animate-fade-in">
            <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm text-center">
              <span className="text-xs font-bold tracking-widest text-purple-600 uppercase block mb-2">Standard Codebook Guidebook</span>
              <h2 className="text-2xl font-black text-slate-800">Pakistan Residential Build Standards (2026)</h2>
              <p className="text-xs text-slate-500 mt-2 max-w-2xl mx-auto">
                These calculations follow strict, time-tested specifications laid out by the Pakistan Engineering Council (PEC) and provincial authorities like LDA, CDA, RDA, and KDA.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-xl">📐</span>
                <h4 className="font-bold text-slate-800 text-sm mt-2 mb-1">Setbacks & Bylaws</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  5 Marla houses usually mandate a 5' front setback lawn. 10 Marla requires 5' back and left setbacks, while 1 Kanal holds 10' front, 5' side setbacks to optimize solar light indices.
                </p>
              </div>
              <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-xl">🧱</span>
                <h4 className="font-bold text-slate-800 text-sm mt-2 mb-1">Standard Concrete Mix</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Plinth beam, pillars, roof slabs, and beams follow 1:2:4 ratio cement-sand-crush ratios matching Grade 60 supreme structural deformed steel rebar support calculations.
                </p>
              </div>
              <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-xl">💰</span>
                <h4 className="font-bold text-slate-850 text-sm mt-2 mb-1">Grey Structure vs Finishing</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Grey structure represents roughly 55-60% of total structural costs in standard homes. Finishing includes custom woodwork, modular kitchens, plumbing fixtures and Premium marble styling.
                </p>
              </div>
            </div>

            <div className="bg-purple-900 rounded-3xl text-white p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
              <div>
                <h3 className="text-lg font-bold">Constructing in Pakistan?</h3>
                <p className="text-xs text-purple-200 mt-1 max-w-lg leading-relaxed">
                  Get certified structural review blueprints, mechanical HVAC designs, custom electrical drafts, and detailed site supervisor planning from specialized civil consultant Muhammad Usman Awan.
                </p>
              </div>
              <a
                href={generateWhatsAppURI()}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-green-500 hover:bg-green-600 text-white font-bold rounded-xl text-xs transition-all flex items-center gap-1.5 shadow"
              >
                Inquire Layout Verification <ArrowRight />
              </a>
            </div>
          </div>
        )}

        {activeTab === "dashboard" && (
          <div className="max-w-7xl mx-auto p-6 w-full space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  <FolderOpen className="text-purple-600" />
                  My Projects Dashboard
                </h2>
                <p className="text-xs text-slate-500">
                  Manage and quickly load previously analyzed house layouts stored in your local session index.
                </p>
              </div>
              <span className="px-3 py-1 bg-purple-100 text-purple-700 text-[10px] font-bold rounded-full">
                {savedDesigns.length} Projects Saved
              </span>
            </div>

            {savedDesigns.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 border border-slate-100 flex flex-col items-center text-center justify-center max-w-md mx-auto shadow-sm">
                <span className="text-5xl mb-4">🗄️</span>
                <h4 className="font-bold text-slate-800 text-sm">Portfolio acts empty</h4>
                <p className="text-xs text-slate-400 mt-1.5 mb-4 leading-relaxed">
                  Go back to the Design Studio tab to configure plot criteria, target rates, and archive layouts directly to this board.
                </p>
                <button
                  onClick={() => setActiveTab("studio")}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl transition-all"
                >
                  Create Design Blueprint
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {savedDesigns.map((saved) => (
                  <div key={saved.id} className="bg-white border border-gray-150 rounded-3xl overflow-hidden shadow-sm flex flex-col justify-between hover:border-purple-300 transition-all">
                    <div className="p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="px-2.5 py-1 bg-purple-50 text-purple-700 font-bold rounded-full text-[9px] uppercase">
                          {saved.design.style} Style
                        </span>
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => exportDesignPDF(saved.design)}
                            className="p-1.5 text-slate-500 hover:text-purple-600 text-xs bg-slate-100 rounded-lg hover:bg-purple-50 transition-all"
                            title="Export PDF"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteSaved(saved.id)}
                            className="p-1.5 text-red-500 hover:text-red-700 text-xs bg-slate-100 rounded-lg hover:bg-red-50 transition-all"
                            title="Delete layout"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-bold text-slate-800 text-sm hover:text-purple-600 transition-all cursor-pointer" onClick={() => handleLoadSaved(saved)}>
                          {saved.design.title}
                        </h4>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-1">
                          <Clock className="w-3 h-3" />
                          Saved: {new Date(saved.savedAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 grid grid-cols-2 gap-2 text-[10px]">
                        <div>
                          <span className="text-slate-400 block uppercase font-bold">Total Budget</span>
                          <span className="font-extrabold text-slate-700">PKR {saved.design.budgetPKR.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block uppercase font-bold">Estimated Cost</span>
                          <span className="font-extrabold text-purple-600">PKR {saved.design.costBreakdown.totalCost.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block uppercase font-bold">Size</span>
                          <span className="font-extrabold text-slate-700">{saved.design.plotSize.value} Marlas</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block uppercase font-bold">Floors</span>
                          <span className="font-extrabold text-slate-700">{saved.design.floorsCount} Floors</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-50 px-5 py-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[9px] font-black text-slate-400">{saved.design.rooms.length} rooms created</span>
                      <button
                        onClick={() => handleLoadSaved(saved)}
                        className="text-xs font-bold text-purple-600 hover:text-purple-800 flex items-center gap-1.5"
                      >
                        Adjust Layout <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "studio" && (
          <div className="flex-1 flex flex-col xl:flex-row divide-y xl:divide-y-0 xl:divide-x divide-gray-150">
            
            {/* Left Control Sidebar form panel */}
            <aside id="design_studio_params" className="w-full xl:w-80 bg-white p-6 flex flex-col gap-6 shrink-0 h-auto xl:h-[calc(100vh-112px)] overflow-y-auto">
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                  <Building className="w-4 h-4 text-purple-600" />
                  Plot Parameters
                </h3>
                
                <div className="space-y-4">
                  {/* Plot size selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1.5">Plot Area Size</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        id="plot_5_marla_btn"
                        onClick={() => setPlotValue(5)}
                        className={`p-2 border rounded-xl text-xs font-black transition-all ${
                          plotValue === 5
                            ? "border-purple-600 bg-purple-50 text-purple-600 shadow-sm font-black"
                            : "border-slate-200 bg-white hover:border-slate-350 text-slate-700"
                        }`}
                      >
                        5 Marla
                      </button>
                      <button
                        id="plot_10_marla_btn"
                        onClick={() => setPlotValue(10)}
                        className={`p-2 border rounded-xl text-xs font-black transition-all ${
                          plotValue === 10
                            ? "border-purple-600 bg-purple-50 text-purple-600 shadow-sm font-black"
                            : "border-slate-200 bg-white hover:border-slate-350 text-slate-700"
                        }`}
                      >
                        10 Marla
                      </button>
                      <button
                        id="plot_1_kanal_btn"
                        onClick={() => setPlotValue(20)}
                        className={`p-2 border rounded-xl text-xs font-black transition-all ${
                          plotValue === 20
                            ? "border-purple-600 bg-purple-50 text-purple-600 shadow-sm font-black"
                            : "border-slate-200 bg-white hover:border-slate-350 text-slate-700"
                        }`}
                      >
                        1 Kanal
                      </button>
                    </div>
                  </div>

                  {/* Floors count selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1.5">Floors / Storeys</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[1, 2, 3].map((num) => (
                        <button
                          key={num}
                          onClick={() => setFloorsCount(num)}
                          className={`p-2 border rounded-xl text-xs font-black transition-all ${
                            floorsCount === num
                              ? "border-purple-600 bg-purple-50 text-purple-600 shadow-sm font-black"
                              : "border-slate-200 bg-white hover:border-slate-200 text-slate-705"
                          }`}
                        >
                          {num === 1 ? "Ground" : num === 2 ? "Double" : "Triple"}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Target budget input slider */}
                  <div>
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-600 mb-1.5">
                      <span>Target Budget (PKR)</span>
                      <span className="font-extrabold text-slate-800">
                        {targetBudget >= 10000000
                          ? `Rs. ${(targetBudget / 10000000).toFixed(2)} Crore`
                          : `Rs. ${(targetBudget / 100000).toFixed(0)} Lakh`}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={4000000}
                      max={40000000}
                      step={50000}
                      value={targetBudget}
                      onChange={(e) => setTargetBudget(Number(e.target.value))}
                      className="w-full accent-purple-600 h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-600" />
                  Style & Aesthetic
                </h3>
                
                <div className="space-y-2">
                  {[
                    { style: ArchitecturalStyle.MODERN, title: "Modern Minimal", desc: "Flat roof structures, huge structural glass facades" },
                    { style: ArchitecturalStyle.TRADITIONAL, title: "Traditional Heritage", desc: "Sloped dynamic brick tiles, colonial structural arches" },
                    { style: ArchitecturalStyle.LUXURY, title: "Spanish Luxury Villa", desc: "Premium imperial arches, elegant marbles, fine fixtures" }
                  ].map((item) => (
                    <button
                      key={item.style}
                      onClick={() => setPrefStyle(item.style)}
                      className={`w-full p-3 border rounded-xl text-left transition-all flex items-start gap-2.5 ${
                        prefStyle === item.style
                          ? "border-purple-600 bg-purple-50 text-purple-600 shadow-sm"
                          : "border-gray-150 bg-white hover:border-slate-350 text-slate-700"
                      }`}
                    >
                      <div className="p-1.5 bg-white border border-slate-100 rounded-lg text-lg">
                        {item.style === ArchitecturalStyle.MODERN ? "🏙️" : item.style === ArchitecturalStyle.TRADITIONAL ? "🕌" : "🏛️"}
                      </div>
                      <div className="leading-snug truncate">
                        <span className="block text-xs font-black">{item.title}</span>
                        <span className="block text-[9px] text-slate-400">{item.desc}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Rate factors local adjustments */}
              <div className="border-t border-slate-100 pt-4 mt-auto">
                <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1">
                  <Calculator className="w-3.5 h-3.5" /> Market Rates Customization
                </h4>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div>
                    <label className="text-slate-400 block mb-0.5">Labor (PKR/sqft)</label>
                    <input
                      type="number"
                      value={laborRate}
                      onChange={(e) => setLaborRate(Number(e.target.value))}
                      className="w-full p-1 border border-slate-200 rounded text-xs bg-slate-50 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-0.5">Bricks (PKR/pcs)</label>
                    <input
                      type="number"
                      value={brickRate}
                      onChange={(e) => setBrickRate(Number(e.target.value))}
                      className="w-full p-1 border border-slate-200 rounded text-xs bg-slate-50 font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Generate Trigger Action */}
              <button
                id="generate_studio_btn"
                onClick={() => handleGenerate(false)}
                disabled={isGenerating}
                className={`w-full py-3.5 rounded-xl font-black text-xs text-white transition-all flex items-center justify-center gap-2 ${
                  isGenerating
                    ? "bg-purple-400 cursor-not-allowed"
                    : "bg-purple-600 hover:bg-purple-700 shadow-md shadow-purple-100 active:scale-98"
                }`}
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 animate-pulse" />
                    Synthesize AI Architectural Draft
                  </>
                )}
              </button>
            </aside>

            {/* Middle and Right Viewports */}
            <section className="flex-1 bg-slate-50 p-6 flex flex-col gap-6 overflow-y-auto h-auto xl:h-[calc(100vh-112px)] max-w-full">
              
              {/* Progress Bar overlay */}
              {isGenerating && (
                <div className="p-6 bg-purple-900 rounded-3xl text-white shadow-lg animate-pulse flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-widest opacity-80">AI Real-time Optimizer Engine</span>
                    <span className="text-xs font-mono font-bold bg-purple-800 px-2 py-0.5 rounded">94% Core Ready</span>
                  </div>
                  <h4 className="text-lg font-black">{progressStep}</h4>
                  <div className="w-full h-2 bg-purple-800 rounded-full overflow-hidden">
                    <div className="w-10/12 h-full bg-green-400 animate-pulse transition-all duration-300"></div>
                  </div>
                </div>
              )}

              {currentDesign && !isGenerating && (
                <>
                  {/* Top quick stats cards */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-5 flex flex-col justify-between">
                      <span className="text-[10px] font-extrabold uppercase text-slate-400">Est. Combined Cost</span>
                      <div id="cost_stat_value" className="text-2xl font-black text-green-600 font-mono mt-1.5">
                        PKR {currentDesign.costBreakdown.totalCost >= 10000000
                          ? `${(currentDesign.costBreakdown.totalCost / 10000000).toFixed(2)} Crore`
                          : `${(currentDesign.costBreakdown.totalCost / 100000).toFixed(0)} Lakh`}
                      </div>
                      <div className="text-[9px] text-slate-400 font-bold mt-1">
                        +10% Contractor margin included
                      </div>
                    </div>

                    <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-5 flex flex-col justify-between">
                      <span className="text-[10px] font-extrabold uppercase text-slate-400">Total Cement Bags</span>
                      <div id="cement_stat_value" className="text-2xl font-black text-slate-800 mt-1.5">
                        {(currentDesign.materials.find(m => m.name.includes("Cement"))?.quantity || 1200).toLocaleString()}{" "}
                        <span className="text-xs font-semibold text-slate-500">Bags</span>
                      </div>
                      <div className="w-full h-1.5 bg-gray-100 rounded-full mt-2 overflow-hidden">
                        <div className="h-full bg-purple-500" style={{ width: "65%" }}></div>
                      </div>
                    </div>

                    <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-5 flex flex-col justify-between">
                      <span className="text-[10px] font-extrabold uppercase text-slate-400">Deformed Steel</span>
                      <div id="steel_stat_value" className="text-2xl font-black text-slate-800 mt-1.5">
                        {(currentDesign.materials.find(m => m.name.includes("Steel"))?.quantity || 4.2).toLocaleString()}{" "}
                        <span className="text-xs font-semibold text-slate-500">Tons</span>
                      </div>
                      <div className="text-[9px] text-green-600 font-extrabold tracking-tight mt-1 animate-pulse uppercase">
                        OPTIMIZED TO BEAM SHEAR
                      </div>
                    </div>

                    <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-5 flex flex-col justify-between">
                      <span className="text-[10px] font-extrabold uppercase text-slate-400">Total Raw Bricks</span>
                      <div id="brick_stat_value" className="text-2xl font-black text-slate-800 mt-1.5 font-mono">
                        {(currentDesign.materials.find(m => m.name.includes("Bricks"))?.quantity || 65000).toLocaleString()}
                      </div>
                      <div className="text-[9px] text-slate-400 font-bold mt-1">
                        Solid 9" Double brick layout sets
                      </div>
                    </div>
                  </div>

                  {/* Floor selection and layout tabs */}
                  <div className="flex bg-slate-200 p-1 rounded-2xl max-w-md gap-1">
                    <button
                      id="floor_view_none_btn"
                      onClick={() => setActiveFloor(-1)}
                      className={`flex-1 py-2 text-xs font-black transition-all rounded-xl ${
                        activeFloor === -1 ? "bg-white text-purple-600 shadow-sm" : "text-slate-600 hover:text-purple-600"
                      }`}
                    >
                      3D Perspective
                    </button>
                    {Array.from({ length: currentDesign.floorsCount }).map((_, fIdx) => (
                      <button
                        key={fIdx}
                        id={`floor_view_f_${fIdx}_btn`}
                        onClick={() => setActiveFloor(fIdx)}
                        className={`flex-1 py-2 text-xs font-black transition-all rounded-xl ${
                          activeFloor === fIdx ? "bg-white text-purple-600 shadow-sm" : "text-slate-600 hover:text-purple-600"
                        }`}
                      >
                        {fIdx === 0 ? "GF Layout" : fIdx === 1 ? "1st Floor" : "2nd Floor"}
                      </button>
                    ))}
                  </div>

                  {/* Main split: Visual render window */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
                    
                    {/* Interactive 3D visual view */}
                    <div className="h-[430px] lg:h-auto min-h-[380px] flex flex-col">
                      <House3DViewer design={currentDesign} activeFloor={activeFloor} />
                    </div>

                    {/* AI intelligent feedback recommendations panel & Cost chart split */}
                    <div className="space-y-6">
                      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 space-y-4">
                        <div className="flex justify-between items-start border-b border-gray-100 pb-3">
                          <div>
                            <span className="text-[9px] font-extrabold text-purple-600 uppercase tracking-wider block">AI Audit Summary</span>
                            <h4 id="ai_summary_title" className="text-md font-bold text-slate-800">Professional Structural Index</h4>
                          </div>
                          <div className="flex gap-1.5">
                            <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-[10px] font-bold rounded">
                              Space Eff: {currentDesign.aiFeedback.spaceEfficiencyRating}/10
                            </span>
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded">
                              Vent: {currentDesign.aiFeedback.ventilationRating}/10
                            </span>
                          </div>
                        </div>

                        <p id="ai_description" className="text-xs text-slate-500 leading-relaxed italic">
                          "{currentDesign.aiFeedback.description}"
                        </p>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="text-[10px] uppercase font-extrabold text-emerald-600 tracking-wider mb-2">Selected Key Merits</h5>
                            <ul className="space-y-1.5 text-xs text-slate-600 font-medium">
                              {currentDesign.aiFeedback.merits.map((m, mI) => (
                                <li key={mI} className="flex items-start gap-1.5">
                                  <span className="text-emerald-500 font-bold">✓</span>
                                  {m}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h5 className="text-[10px] uppercase font-extrabold text-purple-600 tracking-wider mb-2">Actionable Suggestions</h5>
                            <ul className="space-y-1.5 text-xs text-slate-600 font-medium">
                              {currentDesign.aiFeedback.recommendations.map((r, rI) => (
                                <li key={rI} className="flex items-start gap-1.5">
                                  <span className="text-purple-500 font-bold">✦</span>
                                  {r}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                      {/* Construction pricing category meter */}
                      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-extrabold uppercase text-slate-405 tracking-wider">
                            Structural Cost Allocations (BoQ)
                          </h4>
                          <span className="text-[10px] font-bold text-slate-400">Total Est: PKR {currentDesign.costBreakdown.totalCost.toLocaleString()}</span>
                        </div>
                        
                        <div className="space-y-3.5">
                          {currentDesign.costBreakdown.categories.map((cat, cIdx) => (
                            <div key={cIdx} className="space-y-1">
                              <div className="flex justify-between items-center text-xs">
                                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
                                  {cat.name}
                                </span>
                                <span className="text-slate-400 text-[10px]">
                                  {cat.percentage}% (PKR {cat.amount.toLocaleString()})
                                </span>
                              </div>
                              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full rounded-full" style={{ width: `${cat.percentage}%`, backgroundColor: cat.color }} />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 2D Interactive Blueprint section (available only when looking at a specific floor) */}
                  {activeFloor !== -1 && (
                    <div className="animate-fade-in">
                      <House2DBlueprint
                        design={currentDesign}
                        activeFloor={activeFloor}
                        onUpdateRooms={handleUpdateRooms}
                      />
                    </div>
                  )}

                  {/* Complete Material estimation tables */}
                  <div className="bg-white rounded-3xl border border-gray-150 shadow-sm p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-4 mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                          <Calculator className="text-purple-600 w-5 h-5 animate-pulse" />
                          Construction material estimation system
                        </h3>
                        <p className="text-xs text-slate-500">
                          Complete dynamic calculations mapping current standard material items for high grade builds in Pakistan.
                        </p>
                      </div>

                      {/* Material tab filter */}
                      <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-semibold self-start">
                        {(["all", "structural", "finishing", "fittings"] as const).map((catKey) => (
                          <button
                            key={catKey}
                            onClick={() => setMaterialFilterCategory(catKey)}
                            className={`px-3 py-1.5 capitalize rounded-lg transition-all ${
                              materialFilterCategory === catKey ? "bg-white text-purple-600 shadow-sm" : "text-slate-500 hover:text-purple-600"
                            }`}
                          >
                            {catKey}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table id="materials_boq_table" className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-400 text-[10px] font-black uppercase tracking-wider">
                            <th className="py-2.5 px-3">Description Item</th>
                            <th className="py-2.5 px-3">Category Class</th>
                            <th className="py-2.5 px-3 text-right">Required Quantity</th>
                            <th className="py-2.5 px-3 text-right">Material Rate (PKR)</th>
                            <th className="py-2.5 px-3 text-right">Sum Cost Estimation (PKR)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs text-slate-600">
                          {currentDesign.materials
                            .filter((m) => materialFilterCategory === "all" || m.category === materialFilterCategory)
                            .map((mat, mIdx) => (
                              <tr key={mIdx} className="hover:bg-slate-50/55 transition-all">
                                <td className="py-3 px-3 font-semibold text-slate-800">{mat.name}</td>
                                <td className="py-3 px-3 capitalize">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    mat.category === "structural" ? "bg-gray-100 text-gray-700" : mat.category === "finishing" ? "bg-purple-50 text-purple-700" : "bg-emerald-50 text-emerald-700"
                                  }`}>
                                    {mat.category}
                                  </span>
                                </td>
                                <td className="py-3 px-3 text-right font-bold text-slate-800">{mat.quantity.toLocaleString()} {mat.unit}</td>
                                <td className="py-3 px-3 text-right text-slate-400">PKR {mat.rate.toLocaleString()}</td>
                                <td className="py-3 px-3 text-right font-extrabold text-slate-850">PKR {mat.totalPrice.toLocaleString()}</td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Call to actions bottom bar */}
                  <div className="bg-white rounded-3xl p-6 border border-gray-150 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm">Satisfied with the AI floor plan generation?</h4>
                      <p className="text-xs text-slate-500 mt-1">
                        Save this configuration draft to your custom portfolio session, or export to PDF instantly.
                      </p>
                    </div>
                    <div className="flex gap-3">
                      <button
                        id="save_lay_btn"
                        onClick={handleSaveDesign}
                        className="px-5 py-2.5 bg-purple-50 text-purple-600 font-extrabold text-xs rounded-xl hover:bg-purple-100 transition-all flex items-center gap-1.5"
                      >
                        <Bookmark className="w-4 h-4" /> Save project
                      </button>
                      <button
                        id="export_report_btn"
                        onClick={() => exportDesignPDF(currentDesign)}
                        className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl transition-all flex items-center gap-1.5"
                      >
                        <Download className="w-4 h-4" /> Download PDF Report Layout
                      </button>
                    </div>
                  </div>
                </>
              )}
            </section>
          </div>
        )}
      </main>

      {/* Sticky Bottom Footer Support and credits branding */}
      <footer className="h-14 bg-white border-t border-gray-100 px-6 lg:px-12 flex items-center justify-between shrink-0 z-30 shadow-inner">
        <div className="text-[10px] font-black text-slate-40 tracking-widest uppercase">
          Designed by Mr Muhammad Usman Awan
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden sm:flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">
              AI ENGINE COMPLIANT
            </span>
          </div>

          <a
            id="whatsapp_support_footer_btn"
            href={generateWhatsAppURI()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-green-50 text-green-750 border border-green-200 rounded-full text-xs font-bold hover:bg-green-100 transition-all shadow-sm"
          >
            <span className="text-md">💬</span> Speak to Designer Awan
          </a>
        </div>
      </footer>
    </div>
  );
}
